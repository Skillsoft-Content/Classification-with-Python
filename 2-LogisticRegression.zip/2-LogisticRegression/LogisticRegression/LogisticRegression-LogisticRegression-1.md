---
title: 'Intro to classification - Logistic regression - 1'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---





Logistic regression: Topic introduction
=================================================
In this part of the course, we will cover the following concepts:

- Logistic regression use cases and theory behind it
- Data transformation necessary for logistic regression
- Implementation of logistic regression on a dataset
- Model performance evaluation and tuning


Quick Activity
=================================================
- Suppose we want to predict whether a patient will return to our facility

  - What numerical data might be relevant for making this prediction? 
  - What additional qualitative or categorical data might be relevant?
  - How might you handle variables like marital status, education level, or gender?



Module completion checklist
=================================================
<table>
<tr>
<th>Objectives</th>
<th>Complete</th>
</tr>
<tr>
  <td>Determine when to use logistic regression for classification and transformation of target variable</td>
  <td></td>
</tr>
<tr>
  <td>Summarize the process and the math behind logistic regression</td>
  <td></td>
</tr>
</table>


Logistic regression
=================================================

- ~~Logistic regression~~ is a <b>supervised</b> machine learning method used for classification
- The <b>target</b> or <b>dependent</b> variable is ~~binary~~
  
  - Yes or no
  - This or that
  - 1 or 0
  
- The outputs are numerical <b>probabilities</b> that different observations will be in the desired class (`y = 1`), rather than category labels

What logistic regression looks like
=================================================

- The "logistic" in logistic regression comes from the `logit` function (*a.k.a. sigmoid function*)
- The model solves for coefficients to create a curve maximizing the likelihood of correct classification

What logistic regression looks like (cont’d)
=================================================

- The model's performance can be changed by adjusting the ~~cut-off probability~~ where the curve bends, with no need to re-run the model with new parameters
- Note that we convert the target variable to binary values or either 0 or 1 depending on this cut-off or <b>threshold</b>

<div style="text-align:center;">
<img src="/opt/atlassian/pipelines/agent/build/dependencies/img/logistic_regression_curve.png" height=380, width=550>
</div>

<div style="text-align:center;">
[Source](https://towardsdatascience.com/animations-of-logistic-regression-with-python-31f8c9cb420)
</div>

Logistic regression: process
=================================================
<br>
<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/logisticsteps.png)

Converting categorical to binary variable
=================================================
- There are two main ways to prepare the target variable:

  - ~~First method:~~ translate an existing binary variable (i.e., any categorical variable with 2 classes) into `1` and `0` 
  
<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/categoricalconvert.png)

Converting continuous to binary variable
=================================================
- ~~Second method:~~ convert a continuous numeric variable into a binary one

  - We can do this by using a <b>threshold</b> and labeling observations that are higher than that threshold as `1` and `0` otherwise
  - If the median for the example below was `100`, then any point below the median is coded as `0`, and any point above is `1`

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/continuous.png)



Module completion checklist
=================================================
<table>
<tr>
<th>Objectives</th>
<th>Complete</th>
</tr>
<tr>
  <td>Determine when to use logistic regression for classification and transformation of target variable</td>
  <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
</tr>
<tr>
  <td>Summarize the process and the math behind logistic regression</td>
  <td></td>
</tr>
</table>


Linear vs. logistic regression
=================================================
:::::: {.columns}
::: {.column width="50%"}

~~Linear regression line~~

- For data points $x_1, ... , x_n$, we have $y = 0$ or $y = 1$
- The function that "fits" the points is a simple line $\hat{y} = ax + b$

:::
::: {.column width="50%"}

~~Logistic regression curve~~

- For the same data points $x_1, ... , x_n$, $y = 0$ or $y = 1$
- The function that "fits" the data points is a sigmoid $p(y = 1) = \frac{exp(ax + b)}{1 + exp(ax + b)}$

:::
::::::

Logistic regression: function
=================================================
- For every value of $x$, we find $p$ (i.e., probability of success) or probability that $y = 1$ 
- To solve for $p$, logistic regression uses an expression called a ~~sigmoid function:~~

<br>

$$p = \frac{exp(ax + b)}{1 + exp(ax + b)}$$

<br>

- Although it may look a little scary, we can see a very familiar equation inside of the parentheses: $ax + b$
- This is virtually identical to $y = mx + b$


<div class = "notes">
- When you **substitute** $p$ **with the expression above into the equation of a logit function** from the previous slide and perform some algebraic magic, **you will get a simple equation of the line**

$$\hat{y} = logit(p) = log \big(\frac{p}{1-p}\big) = ax + b$$

<p class="centered-text"><i class="orange-emphasis">The link function <code>logit</code> transforms an S-shaped sigmoid function into a straight line. That is why logistic regression is considered a part of GLM family of models!</i></p>
</div>

Logistic regression: the odds ratio 
=================================================

- Through some algebraic transformations that are beyond the scope of this course, we can change this equation

<br>
$$p = \frac{exp(ax + b)}{1 + exp(ax + b)}$$ 

- into a logarithmic expression 

<br>
$$logit(p) = log \big(\frac{p}{1-p}\big)$$
<br>

- Since `p` is the <b>probability of success</b>, `1 - p` is the <b>probability of failure</b>
- The ratio $\big(\frac{p}{1-p}\big)$ is called the ~~odds~~ ratio - it tells us the ~~odds~~ of having a successful outcome with respect to the opposite
- Knowing this provides useful insight into interpreting the resulting <b>coefficients</b>


Logistic regression: coefficients
=================================================
- In <b>linear</b> regression, the coefficients in the equation can easily be interpreted

<br>

<p class="centered-text"> $ax + b$ </p>

<br>

- An increase in $x$ will result in an increase in $y$ and vice versa
- However, in ~~logistic~~ regression, the simplest way to interpret a positive coefficient is with an increase in ~~likelihood~~ 
- A larger value of $x$ increases the likelihood that $y = 1$


<div class="notes">
- One of the main assumptions for `logistic` regression is the distribution of the errors in the model (and the outcome variable $Y$ itself) that can take on only 2 values `0` or `1`; that distribution must be `binomial`
- Another assumption is having the <b class="purple-emphasis">linear relationship between the transformed outcome variable and explanatory variables</b>; that transformation function is `logit` and it <b class="purple-emphasis">links</b> predicted and predictor variables!
</div>

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png) 


Module completion checklist
=================================================
<table>
<tr>
<th>Objectives</th>
<th>Complete</th>
</tr>
<tr>
  <td>Determine when to use logistic regression for classification and transformation of target variable</td>
  <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
</tr>
<tr>
  <td>Summarize the process and the math behind logistic regression</td>
  <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
</tr>
</tr> 
</table>

Congratulations on completing this module!
=================================================
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
