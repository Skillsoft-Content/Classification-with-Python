---
title: 'Intro to classification - Logistic regression - 3'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---




Warm up: overfitting
=================================================
- Based on the graphs below, which model is <b>overfitted</b>? Which is <b>underfitted</b>? Which appears to be a <b>good fit</b>?
- <b>Share your responses</b> in the chat or aloud


![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/fit.png)

<div style="text-align:center;">
[Source](https://towardsdatascience.com/cross-validation-explained-evaluating-estimator-performance-e51e5430ff85)
</div>









Module completion checklist
=================================================
<table>
<tr>
<th>Objectives</th>
<th>Complete</th>
</tr>
<tr>
  <td>Analyze the model to determine if / when overfitting occurs</td>
  <td></td>
</tr> 
<tr>
  <td>Demonstrate how to tune the model using grid search cross-validation</td>
  <td></td>
</tr> 
</table>

Accuracy on train vs. accuracy on test
=================================================

- Our accuracy score for test data was:


```
0.9458577951728636
```

- Take a look at the accuracy score for the training data


```python
# Compute trained model accuracy score.
trained_accuracy_score = logistic_regression_model.score(X_train_scaled, y_train)
print("Accuracy on train data: " , trained_accuracy_score)
```

```
Accuracy on train data:  0.9535923958624546
```

- Did our model underperform?
<br>
- Is there a big difference in `train` and `test` accuracy?
<br>
- If there is a difference, the problem usually lies in ~~overfitting~~



When overfitting occurs
=================================================
:::::: {.columns}
::: {.column width="50%"}

- An overfitted model consists of high variance and usually shows a drastically higher accuracy in the training data because it doesn't generalize well to new data

- Creating a model that fits training data too well will lead to poor generalization and poor performance on new data 

:::
::: {.column width="50%"}

<div style="text-align:center;">
<img src="/opt/atlassian/pipelines/agent/build/dependencies/img/bias-variance.png" height=300>
</div>

:::
::::::


When overfitting occurs (cont'd)
=================================================
:::::: {.columns}
::: {.column width="50%"}

- A model might treat <b>noise</b> as actual artifacts of the data, so when it encounters new data with new noise, it underperforms
- It might use <b>too many predictors</b> that only contribute tiny portions to variation in our data
- The train set might not be an <b>accurate representation</b> of the data, but a partial and inaccurate sample that doesn't translate
  
:::
::: {.column width="50%"}

<div style="text-align:center;">
<img src="/opt/atlassian/pipelines/agent/build/dependencies/img/bias-variance.png" height=300>
</div>

:::
::::::

How to overcome overfitting
=================================================
- Use so-called <b>soft-margin classifiers</b> to:
  
  - Utilize penalization constants and methods to make the model less prone to noise
  - Tune them to use the optimal parameters for best model performance
  
- Use ~~feature selection~~ and/ or ~~feature extraction~~ methods to: 

  - Capture a few main features responsible for the most variation in the data
  - Discard the features that don't account for variation in the data
  
- <b>Gather more data</b>

Tuning logistic regression model
=================================================
- Recall the two parameters that we mentioned before:

  - `penalty`: a regularization technique used to tune the model (either `l1`, a.k.a. _Lasso_, or `l2`, a.k.a. _Ridge_; default is `l2`)
  - `C`: a regularization constant used to amplify the effect of the regularization method (a value between $[0, \infty]$; default is `1`)
- These two parameters control a so-called ~~regularization term~~ that adds a penalty as the model complexity increases with added variables
- These two parameters play a key role in mitigating overfitting and feature pruning
  
Regularization techniques in logistic regression
=================================================
:::::: {.columns}
::: {.column width="50%"}
- As you may know, any ML algorithm optimizes some _cost function_ $f(x)$
<br>

- In logistic regression, `l1` (_Lasso_)  adds a term to that function like so: $$f(x) + C \sum_{j=1}^{n} |b_j|$$
<br>

- While `l2` (_Ridge_) adds a term like so:$$f(x) + C \sum_{j=1}^{n} b_j^2$$

:::
::: {.column width="50%"}
- You can see that _Lasso_ uses the absolute value $b_j$, while _Ridge_ uses a squared $b_j$
<br>

- That term, when added to the original _cost function_, <b>dampens</b> the margins of our classifier, making it more <b>forgiving</b> of the misclassification of some points that might be noise

:::
::::::


Lasso vs. Ridge
=================================================
:::::: {.columns}
::: {.column width="50%"}

<p class="centered-text">~~Lasso (`l1`)~~</p>

$$C \sum_{j=1}^{n} |b_j|$$

- Stands for <b>L</b>east <b>A</b>bsolute <b>S</b>hrinkage and <b>S</b>election <b>O</b>perator
<br>
- It adds "absolute value of magnitude" of the coefficient as a penalty term to the loss function
<br>
- <b>Shrinks</b> (as the name suggests) the less important features' coefficients to zero, which leads to ~~removal~~ of some features

:::
::: {.column width="50%"}

<p class="centered-text">~~Ridge (`l2`)~~</p>

$$C \sum_{j=1}^{n} b_j^2$$

- Adds "squared magnitude" of coefficient as penalty term to the loss function
- <b>Dampens</b> the less important features' coefficients making them less significant, which leads to ~~weighting~~ of the features according to their importance

:::
::::::

What is the role of C?
=================================================

There are ~~4 scenarios~~ that might happen with a classifier with respect to $C$:

- Scenario 1: $C = 0$ 

  - The classifier becomes an <b class="maroon-emphasis">OLS</b> problem (i.e., Ordinary Least Squares, or just a strict regression without any penalization) 
  - Since $0 \times anything = 0$, we are just left with optimizing $f(x)$, which is a definite ~~overfitting~~ problem
    
- Scenario 2: $C = small$

  - We still run into an ~~overfitting~~ problem 
  - Since $C$ will not "magnify" the effect of the penalty term enough

What is the role of C? (cont'd)
=================================================

- Scenario 3: $C = large$

  - We run into an ~~underfitting~~ problem, where we've weighted and dampened the coefficients too much and we made the model too general 
    
- Scenario 4: $C = optimal$

  - We have a <b>good, robust, and generalizable model</b> that works well with new data
  - The model ignores most of the noise while preserving the main pattern in data

- We can pick the right combination of parameters using a technique called ~~grid search cross-validation~~


Module completion checklist
=================================================
<table>
<tr>
<th>Objectives</th>
<th>Complete</th>
</tr>
<tr>
  <td>Analyze the model to determine if / when overfitting occurs</td>
  <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
</tr> 
<tr>
  <td>Demonstrate how to tune the model using grid search cross-validation</td>
  <td></td>
</tr> 
</table>

What does grid search cross-validation do?
=================================================
<div style="text-align:center;">
<img src="/opt/atlassian/pipelines/agent/build/dependencies/img/grid-search-cv.png" height=400>
</div>

scikit-learn: model_selection.GridSearchCV 
=================================================
:::::: {.columns}
::: {.column width="40%"}

- `estimator` is the name of `sklearn` algorithm to optimize
- `param_grid` is a dictionary or list of parameters to optimize
- `cv` is an `int` of `n` for `n-fold` cross-validation
- `verbose` is an `int` of how much verbosity in messages you want to see as the function runs


:::
::: {.column width="60%"}

<div style="text-align:center;">
<img src="/opt/atlassian/pipelines/agent/build/dependencies/img/grid-search-cv-scikit.png" height=250, width=700 style="display:block;margin-left:auto;margin-right:auto;border: 3px solid black">
</div>

<div style="text-align:center;">
[Click here for full documentation](http://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GridSearchCV.html)
</div>

:::
::::::




Prepare parameters for optimization
=================================================


```python
# Create regularization penalty space.
penalty = ['l1', 'l2']
```


```python
# Create regularization constant space.
C = np.logspace(0, 10, 10)
print("Regularization constant: ", C)
```

```
Regularization constant:  [1.00000000e+00 1.29154967e+01 1.66810054e+02 2.15443469e+03
 2.78255940e+04 3.59381366e+05 4.64158883e+06 5.99484250e+07
 7.74263683e+08 1.00000000e+10]
```


```python
# Create hyperparameter options dictionary.
hyperparameters = dict(C = C, penalty = penalty)
print(hyperparameters)
```

```
{'C': array([1.00000000e+00, 1.29154967e+01, 1.66810054e+02, 2.15443469e+03,
       2.78255940e+04, 3.59381366e+05, 4.64158883e+06, 5.99484250e+07,
       7.74263683e+08, 1.00000000e+10]), 'penalty': ['l1', 'l2']}
```

<div class="notes">
- `logspace` function builds a sequence of numbers in `logspace` instead of linear space:

  - The first argument is the start of the sequence (i.e. 0, or logarithm of 1)
  - The second argument is the end of the sequence (i.e. 10, or approximately logarithm of 10000)
  - The third argument is the number of values to generate in the sequence
- We are using logspace because our parameter `C` needs to be a bit more granular in the beginning starting with small values and then needs to grow rather quickly; since logspace generates a sequence of numbers that grow exponentially, it's a good sequence to use for our grid search for optimal `C`
- In general, hyperparameters for every classifier will depend on that classifier, for instance, for trees and boosting we would pick parameters like number of trees to build and others that are a part of that algorithm's input
</div>

Set up cross-validation logistic function
=================================================

```python
# Grid search 10-fold cross-validation with above parameters.
clf = GridSearchCV(linear_model.LogisticRegression(solver='liblinear'), #<- function to optimize
                   hyperparameters,                   #<- grid search parameters
                   cv = 10,                           #<- 10-fold cv
                   verbose = 0)                       #<- no messages to show
```


```python
# Fit CV grid search.
best_model = clf.fit(X_train_scaled, y_train)
best_model
```

```
GridSearchCV(cv=10, estimator=LogisticRegression(solver='liblinear'),
             param_grid={'C': array([1.00000000e+00, 1.29154967e+01, 1.66810054e+02, 2.15443469e+03,
       2.78255940e+04, 3.59381366e+05, 4.64158883e+06, 5.99484250e+07,
       7.74263683e+08, 1.00000000e+10]),
                         'penalty': ['l1', 'l2']})
```



Check best parameters found by CV
=================================================


```python
# Get best penalty and constant parameters.
penalty = best_model.best_estimator_.get_params()['penalty']
constant = best_model.best_estimator_.get_params()['C']
print('Best penalty: ', penalty)
```

```
Best penalty:  l2
```

```python
print('Best C: ', constant)
```

```
Best C:  1.0
```

- It seems like our grid search CV has found that `l1` (i.e. _Lasso_ regularization method) works better than the default `l2` (i.e. _Ridge_)
- It also shows that the default `C`, which is `1`, creates a big enough soft margin for our classifier


<div class="notes">
Once more, since parameters for logistic regression that we optimize are `penalty` and `C` we look at them here. For other algorithms the parameters will depend on those algorithms and what you have set up in your dictionary for grid search CV function.
</div>


Predict using the best model parameters
=================================================
- Now let's use the tuned model to predict on our test data

```python
# Predict on test data using best model.
best_predicted_values = best_model.predict(X_test_scaled)
print(best_predicted_values)
```

```
[False False False ... False False False]
```


```python
# Compute best model accuracy score.
best_accuracy_score = metrics.accuracy_score(y_test, best_predicted_values)
print("Accuracy on test data (best model): ", best_accuracy_score)
```

```
Accuracy on test data (best model):  0.9458577951728636
```


Accuracy on train vs. accuracy on test
=================================================

- Take a look at the accuracy score for the training data


```python
# Compute trained model accuracy score.
trained_accuracy_score = best_model.score(X_train_scaled, y_train)
print("Accuracy on train data: " , trained_accuracy_score)
```

```
Accuracy on train data:  0.9535923958624546
```

- What do you notice by comparing the train and test accuracy?


Assessing the tuned model
=================================================
- Now we can start to evaluate this model and compare how it works as compared to the previous version


```python
# Compute confusion matrix for best model.
best_confusion_matrix = metrics.confusion_matrix(y_test, best_predicted_values)
print(best_confusion_matrix)
```

```
[[1450    0]
 [  83    0]]
```


```python
# Create a list of target names to interpret class assignments.
target_names = ['Low value', 'High value']
```



```python
# Compute classification report for best model.
best_class_report = metrics.classification_report(y_test, best_predicted_values, 
                                                  target_names = target_names)
```


```python
print(best_class_report)
```

```
              precision    recall  f1-score   support

   Low value       0.95      1.00      0.97      1450
  High value       0.00      0.00      0.00        83

    accuracy                           0.95      1533
   macro avg       0.47      0.50      0.49      1533
weighted avg       0.89      0.95      0.92      1533
```

Save accuracy score
=================================================
- Let's save our final model


```python
model_final = {'metrics' : "accuracy", 
                                  'values' : round(best_accuracy_score, 4),
                                  'model':'logistic_tuned' }
print(model_final)
```

```
{'metrics': 'accuracy', 'values': 0.9459, 'model': 'logistic_tuned'}
```


Get metrics for ROC curve
=================================================

```python
# Get probabilities instead of predicted values.
best_test_probabilities = best_model.predict_proba(X_test_scaled)
print(best_test_probabilities[0:5, ])
```

```
[[0.97142844 0.02857156]
 [0.83103003 0.16896997]
 [0.98592979 0.01407021]
 [0.85404288 0.14595712]
 [0.96287726 0.03712274]]
```


```python
# Get probabilities of test predictions only.
best_test_predictions = best_test_probabilities[:, 1]
print(best_test_predictions[0:5])
```

```
[0.02857156 0.16896997 0.01407021 0.14595712 0.03712274]
```

Get metrics for ROC curve (cont'd)
=================================================

```python
# Get ROC curve metrics.
best_fpr, best_tpr, best_threshold = metrics.roc_curve(y_test, best_test_predictions)
best_auc = metrics.auc(best_fpr, best_tpr)
print(best_auc)
```

```
0.8516078105525551
```

Plot ROC curve for both models
=================================================
:::::: {.columns}
::: {.column width="50%"}


```python
# Make an ROC curve plot.
plt.title('Receiver Operator Characteristic')
plt.plot(fpr, tpr, 'blue', 
         label = 'AUC = %0.2f'%auc)
plt.plot(best_fpr, best_tpr, 'black', 
         label = 'AUC (best) = %0.2f'%best_auc)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.show()
```

- Does it look as though our model has improved?

:::
::: {.column width="50%"}

<img src="/opt/atlassian/pipelines/agent/build/assets/2-LogisticRegression/LogisticRegression/LogisticRegression-LogisticRegression-3_files/figure-revealjs/unnamed-chunk-25-1.png" style="display: block; margin: auto;" />

:::
::::::

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png) 


Exercise
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/exercise.png)

<br>
<div style="text-align:center;">
You are now ready to try Tasks 9-13 in the Exercise for this topic
</div>








Module completion checklist
=================================================
<table>
<tr>
<th>Objectives</th>
<th>Complete</th>
</tr>
<tr>
  <td>Analyze the model to determine if / when overfitting occurs</td>
  <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
</tr> 
<tr>
  <td>Demonstrate how to tune the model using grid search cross-validation</td>
  <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
</tr> 
</table>

Logistic regression: Topic summary
=================================================
In this part of the course, we have covered:

- Logistic regression use cases and theory behind it
- Data transformation necessary for logistic regression
- Implementation of logistic regression on a dataset
- Model performance evaluation and tuning

Congratulations on completing this module!
=================================================
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
