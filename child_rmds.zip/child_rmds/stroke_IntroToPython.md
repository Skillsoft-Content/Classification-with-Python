---
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
---



Case study: heart disease survey
=================================================
:::::: {.columns}
::: {.column width="65%"}
- According to the World Health Organization (WHO), stroke is the 2nd leading cause of death globally
- [Click here](https://www.kaggle.com/fedesoriano/stroke-prediction-dataset) to see a dataset showing the results of a clinical trial of a heart-disease drug survey on a sample of US adults
- Each row in the data provides relevant information about the adult, including whether they had a stroke or not

:::
::: {.column width="35%"}

<div align = "center">
<img src=/opt/atlassian/pipelines/agent/build/dependencies/img/stroke.png height=300>
</div>

:::
::::::


Case study: heart disease survey (cont'd)
=================================================
:::::: {.columns}
::: {.column width="65%"}

- We would like to explore this data using the features Python has to offer 
- We will distinguish between adults who have had a stroke and those who have not, and then aggregate each group’s demographic information and medical history
- We will try to discover patterns in the characteristics that differentiate the two groups

:::
::: {.column width="35%"}

<div align = "center">
<img src=/opt/atlassian/pipelines/agent/build/dependencies/img/stroke.png height=300>
</div>

:::
::::::

