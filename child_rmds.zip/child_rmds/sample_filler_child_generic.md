---
title: 
subtitle:
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
   width: 1366
   height: 768
  keep_md: yes
---

Application of AI in healthcare
=================================================

- AI-based technologies and machine learning are used in monitoring and predicting diseases and epidemics around the world. 
- Scientists have large amount of data like (_____) collected from different sources. 
- AI helps to collate this information and predict _____ `target`. 
- Predicting these (______) is especially helpful in third-world countries as they lack in crucial (________) and (______).

