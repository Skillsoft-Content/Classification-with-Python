---
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
---


Costa Rican poverty: case study
=================================================
- We will be diving into a case study from the ~~Inter-American Development Bank (IDB)~~
- The ~~IDB~~ conducted a competition amongst data scientists on [Kaggle.com](https://www.kaggle.com/c/costa-rican-household-poverty-prediction)
- Many countries face this same problem of inaccurately assessing social need
- The following case study on Costa Rican poverty levels is a good example of how we can use data science within social sciences

<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/costa.png)

Costa Rican poverty: backstory
=================================================
:::::: {.columns}
::: {.column width="50%"}
~~Costa Rican poverty level prediction~~
<br><br>
As stated by the ~~IDB~~: 

  - Social programs have a hard time making sure the right people are given enough aid 
  - It’s especially tricky when a program focuses on the poorest segment of the population 
  - The world’s poorest typically can’t provide the necessary income and expense records to prove that they qualify

:::
::: {.column width="50%"}
<br>
<br>
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/costa_poverty.jpeg)

:::
::::::
Costa Rican poverty: backstory
=================================================
:::::: {.columns}
::: {.column width="50%"}
~~Proxy Means Test (PMT)~~

  - In Latin America, one popular method uses an algorithm to verify income qualification 
  - It’s called the ~~Proxy Means Test (or PMT)~~
  - With the PMT, agencies use a model that considers a family’s observable household attributes like the material of their walls and ceiling, or the assets found in the home, to classify them and predict their level of need
  - While this is an improvement, accuracy remains a problem as the region’s population grows and poverty declines

:::
::: {.column width="50%"}
<br>
<br>
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/costa_poverty2.png)

:::
::::::
Costa Rican poverty: proposed solution
=================================================
:::::: {.columns}
::: {.column width="50%"}
~~Costa Rican poverty level prediction: proposed solution~~

  - To improve on PMT, the IDB built a competition for Kaggle participants to use methods beyond traditional econometrics
<br><br>

  - The given dataset contains Costa Rican household characteristics with a target of four categories:

    - extreme poverty
    - moderate poverty
    - vulnerable households
    - non-vulnerable households

:::
::: {.column width="50%"}
<br>
<br>
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/costa_poverty_pic1.png)

:::
::::::
Costa Rican poverty: proposed solution
=================================================
:::::: {.columns}
::: {.column width="50%"}
The goal is to develop an algorithm to predict these poverty levels, that can be used on other countries facing the same problem
<br><br>
**We will**

  - Cleaning the dataset 
  - Wrangle the data 
  - Perform visualizations to find meaningful patterns

:::
::: {.column width="50%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/ds_cycle_1.png)

<div class = "notes">
Explain how this is the first stage of the cycle, we are 'asking the questions' about 
the problems we need t solve
</div>

:::
::::::
Predicting poverty
=================================================
:::::: {.columns}
::: {.column width="50%"}
### Ultimate goal

- **Understand** the patterns and groups within the dataset
- **Predict** poverty levels of Costa Rican households and **build** a model that is reproducible for other countries (not covered in this course)


:::
::: {.column width="50%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/predict.png)

- We will work with a simple subset of this dataset to illustrate concepts, and then use few variables of the actual, bigger dataset to reshape and perform visualizations (in the next module)


