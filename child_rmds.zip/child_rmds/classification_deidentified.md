---
title: 
subtitle:
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
   width: 1366
   height: 768
  keep_md: yes
---

Key things to consider for AI in Healthcare
=================================================

- It's a good practice to include demographic data of the patients in order to reveal the hidden patterns associated with the health data For ex: Age, place of birth, gender, blood group etc. plays a key role in the performance of the model
- Always ensure to de-identify the personal information
- Conform to HIPAA regulations
