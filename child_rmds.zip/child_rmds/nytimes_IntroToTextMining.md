---
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
---



New York Times articles: case study
=================================================
:::::: {.columns}
::: {.column width="65%"}
- The New York Times is a widely read American newspaper with an extensive textual archive
- We can better understand its impact by analyzing its frequently-used terms and identifying the topics discussed in each article
- Our starting point is a dataset from [Kaggle](https://www.kaggle.com/aashita/nyt-comments) containing <b>snippets</b> of the paper’s articles
- We will analyze these text snippets to find the <b>most frequent terms</b>
- We will also extract article topics and <b>tag</b> each article with a topic to better understand the main subjects of the articles 

:::
::: {.column width="35%"}

<div align = "center">
<img src=/opt/atlassian/pipelines/agent/build/dependencies/img/ny_times_logo.png height=300>
</div>

:::
::::::

