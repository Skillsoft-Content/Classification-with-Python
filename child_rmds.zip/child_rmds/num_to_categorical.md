---
title: 
subtitle:
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
   width: 1366
   height: 768
  keep_md: yes
---


Detect categorical variables
=================================================
- Before we proceed to using the model we need to make sure our data is in the proper format
- Sometimes your variables will be recognized by Pandas as numeric
- They represent categories, but are encoded as numbers
- Take a look at the following sample:

|  `age` | `response`| 
|--------|-----------|
| 21-30  | 1         | 
| 31-40  | 2         | 
| 21-30  | 3         | 
| 11-20  | 2         | 

- While it's clear that `age` is a categorical variable in this instance, the `response` appears to be numeric

Detect categorical variables (cont'd)
=================================================
- Let's say that there are 100 responses, but there are only `3` unique values in the `response` column
- This is a clear indicator that the `response` variable actually represents certain categories (which may or may not have been decoded in a data dictionary, so always look for one!)
- Without manual inspection it's often not possible to know beforehand
- In the next few slides you will be able to see how such variables can be detected programmatically

How do we know if a number represents a category?
=================================================
- There are a few approaches that could be used
- We could check for a number of unique values within the column and the total number of values in that column

  - We compute a ratio of the former to the latter
  - The smaller the ratio, the higher the possibility of the column of numbers represents categories
- We could also have a set threshold of the number of categories within a variable (a minimum and and a maximum)
- We could also combine the two to make sure we have bounded both the maximum number of categories per column and detected the column with a sensible threshold of categories

Setting up thresholds
=================================================

```python
categorical_threshold = 0.05
max_categories = 100
```

- These thresholds are not set in stone, as they will vary dataset to dataset, but there are a few things you should be aware of when setting them up:

  - It's better to keep the variable numeric if you can, so catching fewer categorical variables is better than the alternative
  - It's going to take a few trial and error runs before you can get your thresholds tweaked to an optimal setting
  - Think of `50%` (i.e. `categorical_threshold=0.5`) as your upper bound, for instance
  - The maximum threshold is there to guard you against those instances where you have a large number of observations, therefore the `categorical_threshold` might be low, but the total number of categories will be high and won't make actual sense
  


Create a convenience function
=================================================

```python
# Convert numeric to categorical when number of unique values is less than threshold
def num_to_categorical(df,  
                       categorical_threshold, 
                       max_categories):

    num_cols = list(set(df.select_dtypes(include=np.number).columns))
    categorical_cols =list()
    
    # Calculate the number of unique values in the dataset.
    for col in num_cols:
        n_unique = df[col].nunique()
        # Calculate the difference between the number of unique values and 
        # the total number of values as a percentage of the total number of values.
        cat_ratio = n_unique/df.shape[0]
        if cat_ratio < categorical_threshold and n_unique < max_categories:
            categorical_cols.append(col)
    if len(categorical_cols)>0:
        print("Converting to cat: %s", str(categorical_cols))
        df[categorical_cols] = df[categorical_cols].astype(object)
    else:
        print("No numeric variables that can be converted to categorical variables")
    return df 
```

Convert numeric to categorical
=================================================

```python
df = num_to_categorical(df, categorical_threshold, max_categories)
print(df.head())
```

