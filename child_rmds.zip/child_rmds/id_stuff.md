---
title: 
subtitle:
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
   width: 1366
   height: 768
  keep_md: yes
---

Who we are
================================================
:::::: {.columns}
::: {.column width="60%"}
- Data Society's mission is to ~~integrate Big Data and machine learning best practices across entire teams~~ and empower professionals to identify new insights


- We provide:
  - High-quality data science training programs
  - Customized executive workshops
  - Custom software solutions and consulting services


- Since 2014, we've worked with thousands of professionals to make their data work for them

:::
::: {.column width="40%"}
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/DSLogo.png)


:::
::::::

How we teach
=================================================
:::::: {.columns}
::: {.column width="30%"}
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/calendarclock.jpg)

:::
::: {.column width="70%"}
- Slides and related code files
- Interactive knowledge checks (with links) 
- Exercises (we give you 2 files and one has the answers)
  
:::
::::::

Best practices for virtual classes
=================================================
:::::: {.columns}
::: {.column width="50%"}
1.  Find a quiet place, free of as many distractions as possible. Headphones are recommended.
2.  Stay on mute unless you are speaking.
3.  Remove or silence alerts from cell phones, e-mail pop-ups, etc. 
4.  Participate in activities and ask questions. This will be interactive!
5.  Give your honest feedback so we can troubleshoot problems and improve the course.

:::
::: {.column width="50%"}
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/house.png)

:::
::::::
Getting to know your classmates
=================================================
:::::: {.columns}
::: {.column width="50%"}
  - Let's head into a breakout room and introduce ourselves
  - You'll have 5-10 minutes to exchange names and departments and talk about what problems you hope to solve by taking this course
  - When you come back, be ready to share 1-2 areas of interest that came up in the discussion

:::
::: {.column width="50%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/icebreaker.png)



