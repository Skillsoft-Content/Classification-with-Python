---
title: 
subtitle:
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
   width: 1366
   height: 768
  keep_md: yes
---
Classification can be used to
=================================================

- Predict new customer Risk and prevent claims fraud
- Predict whether a patient will revisit a healthcare center
- Anticipate diseases of patients who revisit the center
- Classify medical images into categories using advanced neural networks

