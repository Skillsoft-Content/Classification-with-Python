---
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
---



Heart disease survey: case study
=================================================
:::::: {.columns}
::: {.column width="65%"}
- According to the World Health Organization (WHO), stroke is the 2nd leading cause of death globally
- Some of the adults in the US underwent clinical trials as part of a heart-disease
drug survey and the results of that survey are in this dataset from [Kaggle](https://www.kaggle.com/fedesoriano/stroke-prediction-dataset) 
- Each row in the data provides relevant information about the adult including whether they had a stroke or not
- We will use this data to see if we can identify any patterns in stroke victims based on their medical history and other demographics

:::
::: {.column width="35%"}

<div align = "center">
<img src=/opt/atlassian/pipelines/agent/build/dependencies/img/stroke.png height=300>
</div>

:::
::::::

