---
title: 'Decision Trees - Decision Trees - 1'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---





Decision Trees: Topic introduction
=================================================
In this part of the course, we will cover the following concepts:

- Decision Trees use cases and the theory behind them
- Data transformation necessary for decision trees
- Implementation of decision trees on a dataset
- Model performance evaluation and tuning

Decision Tree terms
=================================================
:::::: {.columns}
::: {.column width="40%"}
- This course focuses on a kind of advanced classification method called a ~~decision tree~~

- Every decision tree starts with a specific decision called the ~~root node~~

- The root and ~~leaf nodes~~ hold questions you have to answer

- ~~Branches~~ are lines that connect the nodes

:::
::: {.column width="60%"}


![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/decision_tree_warm_up.png)

<div style="text-align:center;">
[Source](https://www.intellspot.com/decision-tree-examples/)
</div>

:::
::::::

Decision Tree terms
=================================================
:::::: {.columns}
::: {.column width="40%"}
- Which number on the diagram corresponds to the ~~leaf~~ node?

- Share your response in the chat box


:::
::: {.column width="60%"}


![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/decision_tree_warm_up.png)

<div style="text-align:center;">
[Source](https://www.intellspot.com/decision-tree-examples/)
</div>

:::
::::::

Decision Tree terms
=================================================
:::::: {.columns}
::: {.column width="40%"}

- How about the ~~root~~ node?

- Share your response in the chat box

:::
::: {.column width="60%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/decision_tree_warm_up.png)

<div style="text-align:center;">
[Source](https://www.intellspot.com/decision-tree-examples/)
</div>

:::
::::::

Decision Tree terms
=================================================
:::::: {.columns}
::: {.column width="40%"}
- Finally, what is the ~~name~~ of ~~number 2~~?

- Share your response in the chat box

:::
::: {.column width="60%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/decision_tree_warm_up.png)

<div style="text-align:center;">
[Source](https://www.intellspot.com/decision-tree-examples/)
</div>

:::
::::::

Decision Trees: what are they?
=================================================
:::::: {.columns}
::: {.column width="60%"}
- Decision Trees are one of the supervised machine learning models used to perform Classification

  - They have a **tree-like** structure with a root node, branches, and a set of leaf nodes
  - They are easy to **walk through and explain to stakeholders who are not familiar with data science**
  - They are **intuitive** and popular because they ~~provide explicit rules for Classification~~ 
  - They ~~cope well with heterogeneous data, missing data, and nonlinear effects~~
  - They **predict** the target value of an item by **mapping observations about the item** 

:::
::: {.column width="40%"}

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/clouds-eco-environment-9198.png)

:::
::::::

Classification: general use cases
=================================================
- These are some examples of how you would apply classification algorithms in a health setting

<table>
  <tr>
    <th>Question</th>
    <th>Example</th>
  </tr>
  <tr>
    <td>What is this object like?</td>
    <td>Selecting similar medicines with similar purposes</td>
  </tr> 
  <tr>
    <td>Who is this person like?</td>
    <td>Anticipating behavior or preferences of a person based on her similarities with others</td>
  </tr>
  <tr>
    <td>What category is this in?</td>
    <td>Anticipating if your patient is high risk, has an illness, will develop symptoms, etc.</td>
  </tr>
  <tr>
    <td>What is the probability that something is in a given category?</td>
    <td>Determining the probability that a drug is in a particular category; 
    determining the probability that someone will contract an illness</td>
  </tr>
</table>



Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Discuss use cases for Decision Trees  </td>
    <td></td>
  </tr>
  <tr>
    <td>Summarize the concepts and math behind Decision Trees</td>
    <td></td>
  </tr>
</table>



Decision Trees: pros and cons
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Decision Trees are **great** when used for:
  - Classification and Regression
  - Handling numerical and categorical data
  - Handling data with missing values 
  - Handling data with nonlinear relationships between parameters



:::
::: {.column width="50%"}

- Decision Trees are ~~not very good~~ at:
  - <b>Generalization</b>: they are known for overfitting
  - <b>Robustness</b>: small variations in data can result in a different tree
  - <b>Mitigating bias</b>: if some classes dominate, trees may be unbalanced and biased



:::
::::::

Module completion checklist
=================================================
<table>
  <tr>
    <th></th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Discuss use cases for Decision Trees  </td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Summarize the concepts and math behind Decision Trees</td>
    <td></td>
  </tr>
</table>



Decision Trees: process
=================================================

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/decision_tree_process.png)

Growing Decision Trees: find the most important question
=================================================
Which question is more important on a date?<br>

**The most relevant question**

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/are_you_married.png)

<div class ="notes">
The two questions in this example are "Are you married" 
and "What music do you like?". We see here that "Are you married"
carries a higher information gain, therefore, it will be the first question
that we split the data with, as we will see in the next slide.
</div>

Growing Decision Trees: four steps
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/growtree.png)

Growing decision trees: steps with vocabulary
=================================================  
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/treeterminology.png)

Growing Decision Trees: when to stop
=================================================
When should you stop asking questions?

**When the answer no longer provides additional relevant information**

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/what_music_q.png)

Growing Decision Trees: the math of the splits
=================================================
How do we decide which node to split and how to split it?

- There are two ~~impurity~~ functions that are most commonly used with tree-based models
  
  - Gini
  - Entropy

- The **`sklearn.tree` algorithm** uses Gini, so this is the method we will focus on in this module

Growing Decision Trees: Gini
=================================================
Gini measures the ~~probability of misclassification~~ in the model for each branch of a decision tree. Gini ranges from 0 to 1.

$$Gini(E) = 1 - \sum_{j=1}^{c}p_j^2 $$

<center><b>P<i>i</i></b> = the probability that a random selection would have state <i>i</i></center>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/gini_impurity.png)

<div class = "notes">
 - It is ~~less computationally intensive~~ than Entropy
 - It does not require a logarithm so it is ~~faster~~ than using Entropy
</div>

Decision Trees: process
=================================================

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/decision_tree_process.png)

**SO far**, we learned about growing the tree and making the choice on how to proceed regarding step 2. In order to get to step 3 and 4, we will need to work with a dataset next.

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png)



Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Discuss use cases for Decision Trees  </td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Summarize the concepts and math behind Decision Trees</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
</table>

Congratulations on completing this module!
=================================================
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
