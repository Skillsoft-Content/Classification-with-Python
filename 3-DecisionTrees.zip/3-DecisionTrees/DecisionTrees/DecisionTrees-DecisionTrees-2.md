---
title: 'Decision Trees - Decision Trees - 2'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---






Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Transform data in order  to use Decision Trees</td>
    <td></td>
  </tr>
   <tr>
    <td>Implement the Decision Tree algorithm on a small subset</td>
    <td></td>
  </tr>
</table>







Stroke Prediction survey: case study
=================================================
:::::: {.columns}
::: {.column width="65%"}
- According to the World Health Organization (WHO), stroke is the 2nd leading cause of death globally
- [Click here](https://www.kaggle.com/fedesoriano/stroke-prediction-dataset) to see a dataset showing the results of a clinical trial of a heart-disease drug survey on a sample of US adults
- Each row in the data provides relevant information about the adult, including whether they had a stroke or not
- We would like to use this data to predict whether a patient is likely to have a stroke based on their demographic information and medical history

:::
::: {.column width="35%"}

<div align = "center">
<img src=/opt/atlassian/pipelines/agent/build/dependencies/img/stroke.png height=300>
</div>

:::
::::::


Dataset
=================================================

- In order to implement what you learn in this course, we will be using the `healthcare-dataset-stroke-data.csv` dataset 

- We will be working with columns from the dataset such as:




   - `stroke`
   - `gender`
   - `age`
   - `hypertension`
   - `heart_disease`
   - `ever_married`

<br>
 
- We will be using different columns of the dataset to predict `stroke` as the target variable 

Loading packages
=================================================
Let's load the packages we will be using:

```python
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pickle
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import GridSearchCV

#import graphviz
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score
from matplotlib.legend_handler import HandlerLine2D
```

- To install `graphviz` through Anaconda, run the following code in the terminal:

```
conda install graphviz
```
- Then, install `python-graphviz`, which is a Python library for `graphviz`

```
conda install python-graphviz
```



Directory settings
=================================================
- In order to maximize the efficiency of your workflow, you should encode your directory structure into `variables`
- We will use the `pathlib` library
- Let the `main_dir` be the variable corresponding to your `course` folder
- Let `data_dir` be the variable corresponding to your `data` folder


```python
# Set 'main_dir' to location of the project folder
home_dir = Path(".").resolve()
main_dir = home_dir.parent.parent
print(main_dir)
```


```python
data_dir = str(main_dir) + "/data"
print(data_dir)
```



```python
plot_dir = str(main_dir) + "/plots"
if not os.path.exists(plot_dir):
    os.makedirs(plot_dir)
print(plot_dir)
```

Load the dataset
=================================================
- Let's load the entire dataset



```python
df = pd.read_csv(str(data_dir)+"/"+ 'healthcare-dataset-stroke-data.csv')
print(df.head())
```

```
      id  gender   age  ...   bmi   smoking_status stroke
0   9046    Male  67.0  ...  36.6  formerly smoked      1
1  51676  Female  61.0  ...   NaN     never smoked      1
2  31112    Male  80.0  ...  32.5     never smoked      1
3  60182  Female  49.0  ...  34.4           smokes      1
4   1665  Female  79.0  ...  24.0     never smoked      1

[5 rows x 12 columns]
```

Subset data
=================================================
- Remove any columns from the dataframe that are not numeric or categorical as we will not be using them in our models



```python
df = df[['age', 'avg_glucose_level', 'heart_disease', 'ever_married', 'hypertension', 'Residence_type', 'gender', 'smoking_status', 'work_type', 'stroke', 'id']]
print(df.head())
```

```
    age  avg_glucose_level  heart_disease  ...      work_type  stroke     id
0  67.0             228.69              1  ...        Private       1   9046
1  61.0             202.21              0  ...  Self-employed       1  51676
2  80.0             105.92              1  ...        Private       1  31112
3  49.0             171.23              0  ...        Private       1  60182
4  79.0             174.12              0  ...  Self-employed       1   1665

[5 rows x 11 columns]
```


Data prep: check for NAs
=================================================
:::::: {.columns}
::: {.column width="50%"}
- We now check for NAs and there are multiple methods to deal with them


```python
 # Check for NAs. 
print(df.isnull().sum())
```

```
age                     0
avg_glucose_level       0
heart_disease           0
ever_married            0
hypertension            0
Residence_type          0
gender                  0
smoking_status       1544
work_type               0
stroke                  0
id                      0
dtype: int64
```


:::
::: {.column width="50%"}
- If we do have NAs, we could replace them with a mean or 0


```python
percent_missing = df.isnull().sum() * 100 / len(df)
print(percent_missing)
```

```
age                   0.000000
avg_glucose_level     0.000000
heart_disease         0.000000
ever_married          0.000000
hypertension          0.000000
Residence_type        0.000000
gender                0.000000
smoking_status       30.215264
work_type             0.000000
stroke                0.000000
id                    0.000000
dtype: float64
```
:::
::::::

Data prep: check for NAs
=================================================
:::::: {.columns}
::: {.column width="50%"}







```python
# Delete columns containing either 50% or more than 50% NaN Values
perc = 50.0
min_count =  int(((100-perc)/100)*df.shape[0] + 1)
df = df.dropna(axis=1, 
               thresh=min_count)
print(df.shape)
```

```
(5110, 11)
```
:::
::: {.column width="50%"}


```python
# Function to impute NA in both numeric and categorical columns
def fillna(df):
    # Fill numeric columns with mean value
    df = df.fillna(df.mean())    
    # Fill categorical columns with mode value
    df = df.fillna(df.mode().iloc[0])
    return df
  
df = fillna(df)
```
:::
::::::

Data prep: target
=================================================
- The next step of our data cleanup is to ensure the target variable is binary and has a label
- Let's look at the `dtype` of `stroke`


```python
print(df['stroke'].dtypes)
```

```
int64
```

- We want to convert this to `bool` so that is a binary class


```python
# Identify the the two unique classes
threshold = df['stroke'].mean()
df['stroke'] = np.where(df['stroke'] > threshold, 1,0)
```


```python
unique_values = sorted(df['stroke'].unique())
df['stroke'] = np.where(df['stroke'] == unique_values[0],  False,True)
# Check class again.
print(df['stroke'].dtypes)
```

```
bool
```



Summarize the data
=================================================
- Let's use the `.describe()` function within Pandas to summarize our data


```python
print(df.describe())
```

```
               age  avg_glucose_level  ...  hypertension            id
count  5110.000000        5110.000000  ...   5110.000000   5110.000000
mean     43.226614         106.147677  ...      0.097456  36517.829354
std      22.612647          45.283560  ...      0.296607  21161.721625
min       0.080000          55.120000  ...      0.000000     67.000000
25%      25.000000          77.245000  ...      0.000000  17741.250000
50%      45.000000          91.885000  ...      0.000000  36932.000000
75%      61.000000         114.090000  ...      0.000000  54682.000000
max      82.000000         271.740000  ...      1.000000  72940.000000

[8 rows x 5 columns]
```

scikit-learn: tree
=================================================
- We will be using the `DecisionTreeClassifier` library from `scikit-learn`

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/sklearn_tree.png)

- For all the parameters of the `tree` package, visit [scikit-learn's documentation](https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html)


Trees: pre-processing steps
=================================================
- Now that we know the problem and have our `df` dataset loaded, it's time to get the data ready to model
<br>

- Let's start with data pre-processing. 

  - We don't need to scale data since trees are not sensitive to unscaled data
  - We don't need to look at the number of NAs because we already did this and have loaded the cleaned dataset
  

- ~~However, on your own data, these are steps you must walk through before modeling~~


Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Transform data in order  to use decision trees</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
   <tr>
    <td>Implement the decision tree algorithm and predict on test</td>
    <td></td>
  </tr>
</table>

Decision Tree: splitting the data
=================================================
- Let's split our dataset `df` into `X` and `y`
- `X` will contain the predictors
- `y` will contain the target variable


```python
# Split the data into X and y 
columns_to_drop_from_X = ['stroke'] + ['id']
X = df.drop(columns_to_drop_from_X, axis = 1)
y = np.array(df['stroke'])
```

Data prep: numeric variables
=================================================
- In `Decision Trees`, we use ~~numeric data~~ as predictors
- We can **convert categorical data to integer values**


```python
X = pd.get_dummies(X, columns = ['heart_disease', 'ever_married', 'hypertension', 'Residence_type', 'gender', 'smoking_status', 'work_type'], dtype=float, drop_first=True)
print(X.dtypes)
```

```
age                            float64
avg_glucose_level              float64
heart_disease_1                float64
ever_married_Yes               float64
hypertension_1                 float64
Residence_type_Urban           float64
gender_Male                    float64
gender_Other                   float64
smoking_status_never smoked    float64
smoking_status_smokes          float64
work_type_Never_worked         float64
work_type_Private              float64
work_type_Self-employed        float64
work_type_children             float64
dtype: object
```

Decision Tree: running the algorithm
=================================================
- Now let's run our tree on the entire `X` dataset


```python
# Implement the decision tree on X.
clf = tree.DecisionTreeClassifier()
clf_fit = clf.fit(X, y)

# Look at our generated model:
print(clf_fit)
```

```
DecisionTreeClassifier()
```

Visualize: plot_tree
=================================================
:::::: {.columns}
::: {.column width="55%"}
- We can visualize trees by using `sklearn.tree.plot_tree`
- You can read more about it [here](https://scikit-learn.org/stable/modules/generated/sklearn.tree.plot_tree.html)
- We will use it in this module to illustrate the tree we are building


```python
# Set figure size
fig = plt.figure(figsize=(25,20))
# Visualize `clf_fit_small`
tree.plot_tree(clf_fit, 
              feature_names= X.columns,  
              filled=True)
# Save figure
plt.savefig(str(plot_dir)+'/tree.png',format='png',bbox_inches = "tight")
```


```python
plt.show()
```

:::
::: {.column width="45%"}
![centered](/opt/atlassian/pipelines/agent/build/plots/tree.png)
:::
::::::

Decision Tree: `healthcare-dataset-stroke-data.csv`
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Now, let's run the tree on the full ``healthcare-dataset-stroke-data.csv`` dataset
- **We will evaluate the model and add the results to our `model_final` dataframe**

:::
::: {.column width="50%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/tree_pic.png)


:::
::::::
scikit-learn: train_test_split
=================================================
- We will be using the `train_test_split` library from `scikit-learn`

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/train_test.png)

- Inputs are:

  - Lists, NumPy arrays, scipy-sparse matrices, or Pandas DataFrames

- For all the parameters of the `tree` package, visit [scikit-learn's documentation](http://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html)
 

Split into train and test sets
=================================================
- Split the cleaned data into a train set and test set
- Remember, we already imported the package at the start of this lesson
- Otherwise, we would have to import it now


```python
# Split into train and test.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3)

print(X_train.shape, y_train.shape)
```

```
(3577, 14) (3577,)
```

```python
print(X_test.shape, y_test.shape)
```

```
(1533, 14) (1533,)
```

Fit Decision Tree and predict
=================================================
- Now we will run `tree` on `X_train` and `y_train` and then predict on `X_test`


```python
# Implement the decision tree on X_train.
clf = tree.DecisionTreeClassifier()
clf_fit = clf.fit(X_train, y_train)

# Predict on X_test.
y_predict = clf_fit.predict(X_test)
```

- The result is an ~~array of predictions~~


```python
y_predict[:20]
```

```
array([False, False, False, False, False, False, False, False, False,
       False, False, False, False, False, False, False, False, False,
       False, False])
```
- We can determine the accuracy by comparing the predictions against `y_test`


Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png)


Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Transform data in order  to use decision trees</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
   <tr>
    <td>Implement the decision tree algorithm and predict on test</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
</table>

Congratulations on completing this module!
=================================================
<br>
<div style="text-align:center;">
You are now ready to try Tasks 1-6 in the Exercise for this topic
</div>
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
