---
title: 'Decision Trees - Decision Trees - 4'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---





Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Optimize the Decision Tree by tuning the hyperparameters</td>
    <td></td>
  </tr>
  <tr>
    <td>Run the optimized model, predict, and evaluate the new model</td>
    <td></td>
  </tr>
</table>








Decision Trees: process
=================================================

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/decision_tree_process.png)

**SO far** we have grown our tree and made several choices to get to step 4.  We must now continue to improve the tree through optimization.

Ways to optimize a Decision Tree
=================================================
- Building a Decision Tree is affected by several parameters, as seen in the tree we built
- All the values of our original tree are set to the `tree` defaults within `sklearn`
- We are now going to optimize the tree ~~focusing on the four parameters we called out~~

  - `max_depth = None`
  - `min_samples_split = 2`
  - `min_samples_leaf = 1`
  - `max_features = None`
  
Define an optimal number function
=================================================
- Before we optimize individual parameters, let's build a function that will help us store the parameters we will be using in our `optimized_tree`
- The input is:

  - `values` : list of values for given parameter that we iterate through
  - `test_results` : predictions on test set for each parameter that we iterate over
- The output is:

  - `best_value` : the actual parameter value that performs the best and that we will use in our final optimized tree

```python
# Define function that will determine the optimal number for each parameter.
def optimal_parameter(values,test_results):
    best_test_value = max(test_results)
    best_test_index = test_results.index(best_test_value)
    best_value = values[best_test_index]
    return(best_value)
```

Optimize: max depth
=================================================
- `max_depth` indicates how deep the tree can be
- **The deeper the tree, the more splits it has and captures more information about the data**
- <b>But remember, there is a fine line between a well-fit model and an *overfit* model</b>
- In our original model, `max_depth = None`
- Now, we're going to fit a Decision Tree with depths ranging from 1 to 32 and plot the training and test accuracy

Optimize: max depth
=================================================

```python
# Max depth:
max_depths = np.linspace(1, 32, 32, endpoint = True)
train_results = []
test_results = []

for max_depth in max_depths:
   dt = DecisionTreeClassifier(max_depth = max_depth)
   dt.fit(X_train, y_train)
   
   train_pred = dt.predict(X_train)
   acc_train = accuracy_score(y_train, train_pred)
   
   # Add accuracy score to previous train results
   train_results.append(acc_train)
   y_pred = dt.predict(X_test)
   acc_test = accuracy_score(y_test, y_pred)
   # Add accuracy score to previous test results
   test_results.append(acc_test)
```

```python
# Store optimal max_depth.
optimal_max_depth = optimal_parameter(max_depths,test_results)  
```

Plot: max depth
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Let's plot the max depth `train_results` and `test_results` 
- This will allow us to see when the model starts overfitting on train, as well as when the optimal test results are achieved
- **What observations can you make?**

```python
# Plot max depth over 1 - 32. 
line1, = plt.plot(max_depths, train_results, 'b', label= "Train accuracy")
line2, = plt.plot(max_depths, test_results, 'r', label= "Test accuracy")

plt.legend(handler_map={line1: HandlerLine2D(numpoints = 2)})
plt.ylabel('Accuracy')
plt.xlabel('Tree depth')
plt.show()
```

:::
::: {.column width="50%"}

![](/opt/atlassian/pipelines/agent/build/assets/3-DecisionTrees/DecisionTrees/DecisionTrees-DecisionTrees-4_files/figure-revealjs/unnamed-chunk-7-1.png)

:::
::::::
Optimize: min samples split
=================================================
- `min_samples_split` represents the minimum number of samples required to split an internal node
- **This varies between at least one sample at each node and all samples at each node**
- When we ~~increase this parameter, the tree becomes more constrained~~ as it has to consider more samples at each node
- We will vary the parameter from 10% to 100% of the samples

Optimize: min samples split
=================================================

```python
min_samples_splits = np.linspace(0.1, 1.0, 10, endpoint=True)
train_results = []
test_results = []

for min_samples_split in min_samples_splits:
   dt = DecisionTreeClassifier(min_samples_split=min_samples_split)
   dt.fit(X_train, y_train)
   train_pred = dt.predict(X_train)
   acc_train = accuracy_score(y_train, train_pred)
   # Add accuracy score to previous train results
   train_results.append(acc_train)
   y_pred = dt.predict(X_test)
   acc_test = accuracy_score(y_test, y_pred)
   # Add accuracy score to previous test results
   test_results.append(acc_test)
```

```python
# Store optimal max_depth.
optimal_min_samples_split = optimal_parameter(min_samples_splits,test_results) 
```

Plot: min samples split
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Let's plot the min samples split, `train_results` and `test_results` 
- **What observations can you make?**

```python
# Plot min_sample split.
line1, = plt.plot(min_samples_splits, train_results, 'b', label = "Train accuracy")
line2, = plt.plot(min_samples_splits, test_results, 'r', label = "Test accuracy")

plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
plt.ylabel('Accuracy')
plt.xlabel('min samples split')
plt.show()
```

:::
::: {.column width="50%"}

![](/opt/atlassian/pipelines/agent/build/assets/3-DecisionTrees/DecisionTrees/DecisionTrees-DecisionTrees-4_files/figure-revealjs/unnamed-chunk-9-1.png)

:::
::::::
Optimize: min samples leaf
=================================================
- `min_samples_leaf` is the minimum number of samples required to be at a lead node
- This parameter is similar to `min_samples_split` except that ~~this parameter describes the minimum number of samples at the leafs - the base of the tree~~

Optimize: min samples leaf
=================================================

```python
# Min_samples_leaf:
min_samples_leafs = np.linspace(0.1, 0.5, 5, endpoint = True)
train_results = []
test_results = []

for min_samples_leaf in min_samples_leafs:
   dt = DecisionTreeClassifier(min_samples_leaf=min_samples_leaf)
   dt.fit(X_train, y_train)
   train_pred = dt.predict(X_train)
   acc_train = accuracy_score(y_train, train_pred)
   # Add accuracy score to previous train results
   train_results.append(acc_train)
   y_pred = dt.predict(X_test)
   acc_test = accuracy_score(y_test, y_pred)
   # Add accuracy score to previous test results
   test_results.append(acc_test)
```

```python
optimal_min_samples_leafs = optimal_parameter(min_samples_leafs,test_results)
```
Plot: min samples leaf
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Let's plot the min samples leaf `train_results` and `test_results` 
- **What observations can you make?**

```python
# Plot min_sample split.
line1, = plt.plot(min_samples_leafs, train_results, 'b', label= "Train accuracy")
line2, = plt.plot(min_samples_leafs, test_results, 'r', label= "Test accuracy")

plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
plt.ylabel('Accuracy')
plt.xlabel('min samples leafs')
plt.show()
```

:::
::: {.column width="50%"}

![](/opt/atlassian/pipelines/agent/build/assets/3-DecisionTrees/DecisionTrees/DecisionTrees-DecisionTrees-4_files/figure-revealjs/unnamed-chunk-10-1.png)

:::
::::::
Optimize: max features
=================================================
- `max_features` represents the number of features to consider when looking for the best split
- This parameter is set to `None` as its default value, meaning the tree will always look through all features
- This could sometimes cause overfitting and / or is computationally expensive when working with many variables

Optimize: max features
=================================================

```python
# Max_features:
max_features = list(range(1,X.shape[1]))
train_results = []
test_results = []

for max_feature in max_features:
   dt = DecisionTreeClassifier(max_features=max_feature)
   dt.fit(X_train, y_train)
   train_pred = dt.predict(X_train)
   acc_train = accuracy_score(y_train, train_pred)
   # Add accuracy score to previous train results
   train_results.append(acc_train)
   y_pred = dt.predict(X_test)
   acc_test = accuracy_score(y_test, y_pred)
   
   # Add accuracy score to previous test results
   test_results.append(acc_test)
```

```python
optimal_max_features = optimal_parameter(max_features,test_results) 
```

Plot: max features
=================================================
:::::: {.columns}
::: {.column width="60%"}
- Let's plot the max features, `train_results` and `test_results` 
- **What observations can you make?**


```python
# Plot min_sample split.
line1, = plt.plot(max_features, train_results, 'b', label= "Train accuracy")
line2, = plt.plot(max_features, test_results, 'r', label= "Test accuracy")

plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
plt.ylabel('Accuracy')
plt.xlabel('max features')
plt.show()
```

- This is a case of overfitting - we can see max train accuracy for all values of max_features
- The search for the best split does not stop until at least one valid partition of the nodes is found, even if more than `max_features` features is inspected

:::
::: {.column width="40%"}

![](/opt/atlassian/pipelines/agent/build/assets/3-DecisionTrees/DecisionTrees/DecisionTrees-DecisionTrees-4_files/figure-revealjs/unnamed-chunk-11-1.png)

:::
::::::
Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Optimize the Decision Tree by tuning the hyperparameters</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Run the optimized model, predict, and evaluate the new model</td>
    <td></td>
  </tr>
</table>

Optimized model
=================================================
:::::: {.columns}
::: {.column width="50%"}
- We have now walked through four parameters that will help us optimize our Decision Tree
- Remember that when we optimized each parameter, we saved the optimal parameter using our `optimal_parameter` function

:::
::: {.column width="50%"}


```python
print("The optimal max depth is:", optimal_max_depth)
```

```
The optimal max depth is: 1.0
```

```python
print("The optimal min samples split is:", optimal_min_samples_split)
```

```
The optimal min samples split is: 0.1
```

```python
print("The optimal min samples leaf is:", optimal_min_samples_leafs)
```

```
The optimal min samples leaf is: 0.1
```

```python
print("The optimal max features is:", optimal_max_features)
```

```
The optimal max features is: 1
```

:::
::::::
Build optimized model
=================================================
- Now, we will run the optimized model on our `X_train` 

```python
# Set the seed.
np.random.seed(1)

# Implement the Decision Tree on X_train.
clf_optimized = tree.DecisionTreeClassifier(max_depth = optimal_max_depth,
                                            min_samples_split = optimal_min_samples_split,
                                            min_samples_leaf = optimal_min_samples_leafs,
                                            max_features = optimal_max_features)
                                            
# We can now see our optimized features where before they were just default:
print(clf_optimized)
```

```
DecisionTreeClassifier(max_depth=1.0, max_features=1, min_samples_leaf=0.1,
                       min_samples_split=0.1)
```

```python
clf_optimized_fit = clf_optimized.fit(X_train, y_train)
```

Predict with optimized model
=================================================
- Finally, let's predict on `X_test` and calculate our accuracy score
- ~~How is our optimized model doing?~~
- **What other metrics can you also look at?**


```python
# Predict on X_test.
y_predict_optimized = clf_optimized_fit.predict(X_test)

# Get the accuracy score.
acc_score_tree_optimized = accuracy_score(y_test, y_predict_optimized)

print(acc_score_tree_optimized)
```

```
0.9504240052185258
```

Train accuracy
=================================================

```python
# Compute accuracy using training data.
acc_train_tree_optimized = clf_optimized_fit.score(X_train,
                                         y_train)
                                         
print ("Train Accuracy:", acc_train_tree_optimized)
```

```
Train Accuracy: 0.9516354487000279
```


Predict and save results
=================================================

- Now we know some of the parameters that help us optimize our Decision Tree
- ~~What is another way you could optimize the tree, instead of searching each parameter separately?~~

Predict and save results
=================================================
:::::: {.columns}
::: {.column width="40%"}
- This other method is `GridSearchCV`. Although it's helpful, it can be computationally expensive
- Going through each of the four parameters helps you understand your tree a little better
- **Let's see our optimized tree accuracy score in our `model_final` dataset**

:::
::: {.column width="60%"}


```python
# Add the optimized model to our dataframe.
model_final_tree = {'metrics' : "accuracy" , 
             'values' : round(acc_score_tree_optimized,4),
             'model':'tree_all_variables_optimized' }
print(model_final_tree)
```

```
{'metrics': 'accuracy', 'values': 0.9504, 'model': 'tree_all_variables_optimized'}
```


:::
::::::

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png)



Exercise
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/exercise.png)

<br>
<div style="text-align:center;">
You are now ready to try Tasks 8-12 in the Exercise for this topic
</div>

















Module completion checklist
=================================================
<table>
  <tr>
    <th>Objectives</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Optimize the Decision Tree by tuning the hyperparameters</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Run the optimized model, predict, and evaluate the new model</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
</table>

Decision Trees: Topic summary
=================================================
In this part of the course, we have covered:

- Decision Trees use cases and the theory behind them
- Data transformation necessary for Decision Trees
- Implementation of Decision Trees on a dataset
- Model performance evaluation and tuning

Congratulations on completing this module!
=================================================
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
