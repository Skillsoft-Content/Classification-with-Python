---
title: 'Intro to classification - kNN - 4'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---

















Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Perform cross-validation to better understand what the optimal model accuracy might be</td>
    <td></td>
  </tr>
  <tr>
    <td>Uncover optimal hyperparameters with a grid search</td>
    <td></td>
  </tr>
</table>


Finding optimal k
=================================================
- ~~We have now:~~

  - Run kNN on our training data
  - Predicted using the kNN model on our test data 
  - Reviewed performance metrics for classification algorithms
  - Built a confusion matrix for the predicted model
  
- **We will now:**

  - Use cross-validation and re-run the model on the training data
  - Implement grid search to know what our optimal k value is
  - Evaluate the new predictions


Cross-validation: n-fold
=================================================
- To quickly refresh our memory, here is how cross-validation works:

  1. Split the dataset into several subsets ("n" number of subsets) of equal size
  2. ~~Use each subset as the test dataset~~ and **use the rest of the data as the training dataset**
  3. Repeat the process for every subset you create

<br>

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/cross-val-tables.png)

- Cross-validation helps prevent overfitting by performing the model on multiple subsets

Cross-validation in Python
=================================================
- We will be using two functions from `sklearn.model_selection` for cross-validation:

  - `cross_val_score`
  - `GridSearchCV`

- They are both model selection / optimization functions that use cross-validation and they are both part of the `sklearn.model_selection` package

  - `cross_val_score` will help us find the potential optimal model score
  - `GridSearchCV` will run through cross-validation multiple times for a range of given `k` and help us find the optimal value 
  
cross_val_score for optimal accuracy
=================================================
:::::: {.columns}
::: {.column width="40%"}

- Here is a little about `cross_val_score`

:::
::: {.column width="60%"}
![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/sklearn_cross_val.png)

:::
::::::

Cross-validation pipeline for optimal accuracy
=================================================

- We will use the `Pipeline()` function from `sklearn` so that we can follow the preprocessing order of splitting and then scaling before going into the model
- Read more about `Pipeline()` [here](https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html)
- Note that here we use `StandardScaler()` for scaling vs `scale()` which we used before
- These two functions are doing exactly the same thing, but:
  - `scale(x)` is just a function, which transforms some data
  - `StandardScaler()` is a class supporting the Transformer API


```python
# Create a pipeline of the scaler and Estimator
cv_pipeline = Pipeline([('transformer',  StandardScaler()), ('estimator', kNN)])
```

Cross-validation for optimal accuracy
=================================================
- First, let's use `cross_val_score` to understand what our optimal accuracy should be
- We'll take the following steps:

    - using our `kNN_k` model, we train a model with a cross-validation reoccurrence of five times
    - we look at each cross-validation accuracy score
    - we then average the accuracy scores over the 5 times and we use that as our potential optimal model score
    

```python
# Calculate cv scores
cv_scores = cross_val_score(cv_pipeline, X, y, cv = 5)
```
    
- Notice that we don't use our split data, the input is our entire `X` and `y`
- This is because the cross-validation occurs when the function holds out samples for us

Cross-validation for optimal accuracy
=================================================
- Let's look at our output

```python
# Print each cv score (accuracy) and average them.
print(cv_scores)
```

```
[0.94911937 0.94618395 0.9481409  0.95009785 0.9481409 ]
```

```python
print("cv_scores mean:{}".format(np.mean(cv_scores)))
```

```
cv_scores mean:0.9483365949119374
```

```python
mean = np.mean(cv_scores)
print("Optimal cv score is:", round(mean, 4))
```

```
Optimal cv score is: 0.9483
```

Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Perform cross-validation to better understand what the optimal model accuracy might be</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Uncover optimal hyperparameters with a grid search</td>
    <td></td>
  </tr>
</table>


Parameters vs. hyperparameters
=================================================
- ~~Parameters~~

  - Parameters are derived from training data
  - Example: the weights of a predictor in a regression
  - They are learned by the algorithm from the data
  
- ~~Hyperparameters~~

  - Hyperparameters are manually set before the training process
  - Example: k in kNN, number of trees in random forest, penalty in penalized regression
  - They are found using a **grid search**
  
What is a grid search?
=================================================
- ~~Grid search helps us find the optimal hyperparameters~~

  - Grid search allows us to search over a list of hyperparameter values to find the optimal hyperparameter
  - It is a brute force approach: it creates a model for every hyperparameter value in the list
  - We choose the hyperparameter value that created the model with the smallest error
  
- ~~Example kNN~~

  - Grid search allows us to find the optimal `k`
  - We can use a grid search to search over k=1, k=2, k=3, k=4, etc.
  - Grid search creates models for every value of `k` in the list
  - We can choose the `k` that yields the smallest error

Finding the smallest error with grid search
=================================================
:::::: {.columns}
::: {.column width="50%"}
- So far, we have used a ~~train - test split~~ to train and evaluate our models
- This worked because we only had parameters, but no hyperparameters
- Now that we also have hyperparameters in our models, we need a **train - validation - test split**
- The validation set allows us to compare the different models created by the grid search and choose the optimal hyperparameters

:::
::: {.column width="50%"}

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/validation.png)

:::
::::::
Using cross-validation with grid search
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Instead of using train - validation - test split, we can use ~~cross-validation~~
- Cross-validation allows us to perform the split multiple times on the same dataset
- We have new train and validation sets for each fold `n`
- This leads to more accurate results, but is computationally intensive
- It is best suited for small datasets
- In this module, we will use cross-validation with our grid search

:::
::: {.column width="50%"}

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/cross-valid.png)

:::
::::::
Keeping test data separate
=================================================

- Whether you use <b>train - validation - test</b> or <b>cross-validation</b>, you always want to have a separate test set
- The test set must not be involved in the model training and selection process to allow for a ~~true assessment~~
- Only a true assessment tells you how your model will perform on previously unseen data
- The errors on your train and validation sets will be lower than the errors you can expect on previously unseen data

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png) 

Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
    <td>Perform cross-validation to better understand what the optimal model accuracy might be</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Uncover optimal hyperparameters with a grid search</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
</table>

Congratulations on completing this module!
=================================================
<br>
<div style="text-align:center;">
You are now ready to try Task 14 in the Exercise for this topic
</div>
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
