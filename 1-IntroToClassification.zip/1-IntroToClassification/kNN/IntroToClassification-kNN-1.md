---
title: 'Intro to classification - kNN - 1'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---





Topic introduction
=================================================
In this part of the course, we will cover the following concepts:

- Supervised learning and its use cases
- The theory behind kNN algorithm
- Implementation of kNN on a dataset
- Performance optimization for kNN

Chat question
=================================================
:::::: {.columns}
::: {.column width="60%"}
- This course is about ~~classification~~, a machine learning method for determining whether an <b>observation</b> belongs in <b>one category or another</b>
- A common use for classification algorithms is filtering <b>spam email</b>
- What <b>features</b> do you think spam classification algorithms are <b>trained</b> to detect?

:::
::: {.column width="40%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/chat-q-knn.png)

:::
::::::
Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Describe classification and its uses</td>
    <td></td>
  </tr>
  <tr>
    <td>Summarize the steps and application of kNN</td>
    <td></td>
  </tr>
</table>

Classification
=================================================

- Classification is a type of ~~supervised learning~~ method

  - The data for such methods is labeled into ~~classes~~ often by humans, hence the name of the method
- This translates into having two types of variables in our data:

  - **Predictor variables** (a.k.a. features) - can be numeric, categorical, etc.
  - **Target variable** (a.k.a. class variable) - can only be categorical


Classification: binary vs multi-class
=================================================

- Depending how many categories are within the target variable, we will have

  - A **binary** classification model with only **2** possible outcomes 
  - A ~~multi-class~~ classification model with ~~3 or more~~ outcomes


Commonly used classification methods
=================================================

- kNN
- Logistic regression
- Support Vector Machines
- Random Forests
- Do you know of any other methods?

Classification vs Regression
=================================================

- Although we will not be discussing regression as a supervised learning method here, you will certainly encounter it at some point
- Below is table of comparison of some classification and regression methods that could help you navigate through common features and differences between the two

<table>
  <tr>
    <th></th>
    <th>Classification</th>
    <th>Regression</th>
  </tr>
  <tr>
    <td><b>Target variable</b></td>
    <td>Discrete, usually binary</td>
    <td>Continuous</td>
  </tr> 
  <tr>
    <td><b>Types</b></td>
    <td>Binary, Multi-Class</td>
    <td>Linear, polynomial</td>
  </tr>
  <tr>
    <td><b>Algorithms</b></td>
    <td>Decision trees, random forests, logistic regression, k-Nearest Neighbors</td>
    <td>Linear regression, regression trees, time-series regression</td>
  </tr>
</table>


Classification: general use cases
========================================================
- These are some examples of how you would apply classification algorithms in a medical setting

<table>
  <tr>
    <th>Question</th>
    <th>Example</th>
  </tr>
  <tr>
    <td>What is this object like?</td>
    <td>Selecting similar drugs or similar diseases</td>
  </tr> 
  <tr>
    <td>Who is this person like?</td>
    <td>Finding patients that are suffering similar symptoms</td>
  </tr>
  <tr>
    <td>What category is this in?</td>
    <td>Anticipating if your patient will need emergency services</td>
  </tr>
  <tr>
    <td>What is the probability that something is in a given category?</td>
    <td>Determining the probability that a drug is a particular type or can be used for a particular treatment</td>
  </tr>
</table>


Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Describe classification and its uses</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Summarize the steps and application of kNN</td>
    <td></td>
  </tr>
</table>


Steps of kNN
=================================================
<br>
<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/stepsofknn.png)

k-Nearest Neighbors: setup
=================================================
<br>
<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knnusecase.png)

k-Nearest Neighbors: measure
=================================================
<br>
<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knnmeasure.png)

k-Nearest Neighbors: 2-NN for majority vote
=================================================
<br>
<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knnvote.png)

k-Nearest Neighbors: label point
=================================================
<br>
<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knnlabel.png)

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png) 


Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Describe classification and its uses</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Summarize the steps and application of kNN</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
</table>

Congratulations on completing this module!
=================================================
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)

