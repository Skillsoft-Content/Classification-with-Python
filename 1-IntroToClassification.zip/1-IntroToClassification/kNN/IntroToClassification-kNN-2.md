---
title: 'Intro to classification - kNN - 2'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---






Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
 <tr>
    <td>Clean and transform data to run kNN</td>
    <td></td>
  </tr>
  <tr>
    <td>Define cross-validation and discuss how to use it</td>
    <td></td>
  </tr>
  <tr>
</table>






Stroke Prediction survey: case study
=================================================
:::::: {.columns}
::: {.column width="65%"}
- According to the World Health Organization (WHO), stroke is the 2nd leading cause of death globally
- [Click here](https://www.kaggle.com/fedesoriano/stroke-prediction-dataset) to see a dataset showing the results of a clinical trial of a heart-disease drug survey on a sample of US adults
- Each row in the data provides relevant information about the adult, including whether they had a stroke or not
- We would like to use this data to predict whether a patient is likely to have a stroke based on their demographic information and medical history

:::
::: {.column width="35%"}

<div align = "center">
<img src=/opt/atlassian/pipelines/agent/build/dependencies/img/stroke.png height=300>
</div>

:::
::::::




Dataset
=================================================

- In order to implement what you learn in this course, we will be using the `healthcare-dataset-stroke-data` dataset 

- We will be working with columns from the dataset such as:


  
<br>

  - `stroke`
  - `gender`
  - `age`
  - `hypertension`
  - `heart_disease`
  - `ever_married`

<br>
 
- We will be using different columns of the dataset to predict `stroke` as the target variable 


Loading packages
=================================================
Let's load the packages we will be using:

```python
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# We will introduce it when we use it
import pickle
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import scale,StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn import metrics
```



Directory settings
=================================================
- In order to maximize the efficiency of your workflow, you should encode your directory structure into `variables`
- We will use the `pathlib` library
- Let the `main_dir` be the variable corresponding to your `course` folder
- Let `data_dir` be the variable corresponding to your `data` folder


```python
# Set 'main_dir' to location of the project folder
home_dir = Path(".").resolve()
main_dir = home_dir.parent.parent
print(main_dir)
```


```python
data_dir = str(main_dir) + "/data"
print(data_dir)
```


Load data into Python
=================================================
- Let's load the entire dataset
- We are now going to use the function `read_csv` to read in our ``healthcare-dataset-stroke-data.csv`` dataset


```python
df = pd.read_csv(str(data_dir)+"/"+ 'healthcare-dataset-stroke-data.csv')
print(df.head())
```

```
      id  gender   age  ...   bmi   smoking_status stroke
0   9046    Male  67.0  ...  36.6  formerly smoked      1
1  51676  Female  61.0  ...   NaN     never smoked      1
2  31112    Male  80.0  ...  32.5     never smoked      1
3  60182  Female  49.0  ...  34.4           smokes      1
4   1665  Female  79.0  ...  24.0     never smoked      1

[5 rows x 12 columns]
```

Subset data
=================================================
- Remove any columns from the dataframe that are not numeric or categorical as we will not be using them in our models




```python
df = df[['age', 'avg_glucose_level', 'heart_disease', 'ever_married', 'hypertension', 'Residence_type', 'gender', 'smoking_status', 'work_type', 'stroke', 'id']]
print(df.head())
```

```
    age  avg_glucose_level  heart_disease  ...      work_type  stroke     id
0  67.0             228.69              1  ...        Private       1   9046
1  61.0             202.21              0  ...  Self-employed       1  51676
2  80.0             105.92              1  ...        Private       1  31112
3  49.0             171.23              0  ...        Private       1  60182
4  79.0             174.12              0  ...  Self-employed       1   1665

[5 rows x 11 columns]
```


Convert target to binary
=================================================
- Let's check if the target is binary, and convert it to binary if it is not already


```python
# Target not binary - calculate the mean and assign the above mean to 1 and below to 0
threshold = np.mean(df['stroke'])
df['stroke'] = np.where(df['stroke'] > threshold, 1,0)
```


```python
# Target is binary
print(df['stroke'])
```

```
0       1
1       1
2       1
3       1
4       1
       ..
5105    0
5106    0
5107    0
5108    0
5109    0
Name: stroke, Length: 5110, dtype: int64
```

ID variables
=================================================
- We will not use certain columns such as ID variables or variables with more than 50% NAs

  - <b>`id`</b>
- We want to see if the independent variables would predict `stroke` well


Data cleaning steps for kNN
=================================================
:::::: {.columns}
::: {.column width="60%"}

- There are a few steps to remember to take before jumping into splitting the data and training the model
- Let's look at what it means to scale our predictors, and why it's necessary with kNN
- We will also talk through why we need to make sure the target variable is labeled
<br><br>
  1. Make sure the target is labeled
  2. Check for NAs (null values)
  3. Encode categorical data into numerical
  4. Split into train and test
  5. Scale the predictors
  
:::
::: {.column width="40%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/broom.png)
  


:::
::::::
The data at first glance
=================================================
:::::: {.columns}
::: {.column width="60%"}
- Look at the first 3 rows and the data types

```python
# The first 3 rows.
print(df.head(3))
```

```
    age  avg_glucose_level  heart_disease  ...      work_type  stroke     id
0  67.0             228.69              1  ...        Private       1   9046
1  61.0             202.21              0  ...  Self-employed       1  51676
2  80.0             105.92              1  ...        Private       1  31112

[3 rows x 11 columns]
```


:::
::: {.column width="40%"}


```python
# The data types.
print(df.dtypes)
```

```
age                  float64
avg_glucose_level    float64
heart_disease          int64
ever_married          object
hypertension           int64
Residence_type        object
gender                object
smoking_status        object
work_type             object
stroke                 int64
id                     int64
dtype: object
```

- Frequency table of the target variable

```python
print(df['stroke'].value_counts())
```

```
0    4861
1     249
Name: stroke, dtype: int64
```
:::
::::::


Data prep: check for NAs
=================================================

- We now check for NAs and there are multiple methods to deal with them

```python
 # Check for NAs. 
print(df.isnull().sum())
```

```
age                     0
avg_glucose_level       0
heart_disease           0
ever_married            0
hypertension            0
Residence_type          0
gender                  0
smoking_status       1544
work_type               0
stroke                  0
id                      0
dtype: int64
```


Data prep: check for NAs
=================================================
- If we do have NA, we could replace them with a mean or 0

```python
percent_missing = df.isnull().sum() * 100 / len(df)
print(percent_missing)
```

```
age                   0.000000
avg_glucose_level     0.000000
heart_disease         0.000000
ever_married          0.000000
hypertension          0.000000
Residence_type        0.000000
gender                0.000000
smoking_status       30.215264
work_type             0.000000
stroke                0.000000
id                    0.000000
dtype: float64
```


Data prep: check for NAs
=================================================






```python
# Delete columns containing either 50% or more than 50% NaN Values
perc = 50.0
min_count =  int(((100-perc)/100)*df.shape[0] + 1)
df = df.dropna(axis=1, 
               thresh=min_count)
print(df.shape)
```

```
(5110, 11)
```


```python
# Function to impute NA in both numeric and categorical columns
def fillna(df):
    # Fill numeric columns with mean value
    df = df.fillna(df.mean())    
    # Fill categorical columns with mode value
    df = df.fillna(df.mode().iloc[0])
    return df
  
df = fillna(df)
```

```
/opt/conda/envs/sdaia-python-classification/bin/python:3: FutureWarning: Dropping of nuisance columns in DataFrame reductions (with 'numeric_only=None') is deprecated; in a future version this will raise TypeError.  Select only valid columns before calling the reduction.
```

- We are now ready to convert our data to numerical values

Data prep: ready for kNN
=================================================
- The next step of our data cleanup is to ensure the target variable is binary and has a label
- Let's look at the `dtype` of `stroke`


```python
print(df['stroke'].dtypes)
```

```
int64
```

- We want to convert this to `bool` so that is a binary class

```python
# Identify the the two unique classes
unique_values = sorted(df['stroke'].unique())
df['stroke'] = np.where(df['stroke'] == unique_values[0], False,True)
```


```python
# Split the data into X and y 
columns_to_drop_from_X = ['stroke'] + ['id']
X = df.drop(columns_to_drop_from_X, axis = 1)
y = np.array(df['stroke'])
```

Data prep: numeric variables
=================================================
:::::: {.columns}
::: {.column width="50%"}
- In `kNN`, we use ~~numeric data~~ as predictors
- In some cases, we can **convert categorical data to integer values**


```python
print(X.dtypes)
```

```
age                  float64
avg_glucose_level    float64
heart_disease          int64
ever_married          object
hypertension           int64
Residence_type        object
gender                object
smoking_status        object
work_type             object
dtype: object
```

:::
::: {.column width="50%"}



```python
X = pd.get_dummies(X, columns = ['heart_disease', 'ever_married', 'hypertension', 'Residence_type', 'gender', 'smoking_status', 'work_type'], dtype=float, drop_first=True)
print(X.dtypes)
```

```
age                            float64
avg_glucose_level              float64
heart_disease_1                float64
ever_married_Yes               float64
hypertension_1                 float64
Residence_type_Urban           float64
gender_Male                    float64
gender_Other                   float64
smoking_status_never smoked    float64
smoking_status_smokes          float64
work_type_Never_worked         float64
work_type_Private              float64
work_type_Self-employed        float64
work_type_children             float64
dtype: object
```

:::
::::::


Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
    <td>Clean and transform data to run kNN</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Define cross-validation and discuss how to use it</td>
    <td></td>
  </tr>
</table>

Introducing cross-validation
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Before applying any machine learning algorithms on the data, we usually need to split the data into a ~~train set~~ and a **test set** 
- But now, we are doing this <b>multiple times</b>
- We have a new **test set** for each fold `n`
- The rest of the data is the ~~train set~~

:::
::: {.column width="50%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/validated.jpeg)

:::
::::::
Why do we use cross-validation?
=================================================
- Cross-validation is helpful in multiple ways:

  - It tunes our model better by running it multiple times on our data (instead of just once on the train set and once on the test set)
  - You get assurance that your model has most of the patterns from the data correct and it's not picking up too much on the noise
  - It finds optimal parameters for your model because it runs multiple times

Cross-validation: train and test
=================================================
:::::: {.columns}
::: {.column width="50%"}
~~Train~~

- This is the data that you train your model on
- Use a larger portion of the data to train so that the model gets a large enough sample of the population
- Usually about ~~70%~~ of your dataset
- <b>When there is not a large population to begin with, cross-validation techniques can be implemented</b>

:::
::: {.column width="50%"}

~~Test~~

- This is the data that you test your model on
- Use a smaller portion to test your trained model on
- Usually about **30%** of your dataset
- <b>When cross-validation is implemented, small test sets will be held out multiple times</b>


:::
::::::
Cross-validation: n-fold
=================================================
Here is how cross-validation works:

  1. Split the dataset into several subsets ("n" number of subsets)
  of equal size
  2. ~~Use each subset as the test dataset~~ and **use the rest of the
  data as the training dataset**
  3. Repeat the process for every subset you create

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/cross-val-tables.png)

Train and test: small scale before n-fold
=================================================
- Before we actually use n-fold cross-validation:
  
  - We split our data into a train and test set
  - We run kNN initially on the training data
  

```python
# Set the seed.
np.random.seed(1)

# Split into train and test.
X_train, X_test, y_train, y_test = train_test_split(X, 
                                                    y, 
                                                    test_size = 0.3) 
```

- Success! Now let's scale our predictors


Data prep: scaling variables
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Once the data is converted to `numeric` (if necessary), we ~~scale~~ the dataset to make sure that we can properly calculate the relationship between variables
- There are a few methods to scale data and we will use the `scale` function from `sklearn.preprocessing`
- A few things to remember about `scale`:
  - It is a generic function whose default method ~~centers~~ and/or scales the columns of a numeric matrix
  - It will convert your dataset to have a `mean` of `0` and a `standard deviation` of `1` 

:::
::: {.column width="50%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/sklearn.scale.png)


:::
::::::
Data prep: scaling variables
=================================================
- We scale only our predictors
- We scale our X and y predictors separately


```python
# Scale X.
X_train = scale(X_train)
X_test = scale(X_test)
```

```python
print(X_train[0:2])
```

```
[[ 0.60884288  0.63825752 -0.23816135  0.71900176 -0.33037446  0.99414629
   1.17402064  0.          0.69941096 -0.42534432 -0.06910341  0.86404979
  -0.43810503 -0.3922639 ]
 [-1.88698872 -0.38666334 -0.23816135 -1.39081718 -0.33037446 -1.00588818
  -0.85177378  0.          0.69941096 -0.42534432 -0.06910341 -1.15734072
  -0.43810503  2.54930418]]
```

```python
print(X_test[0:2])
```

```
[[-0.04508466  0.12994683 -0.24077171  0.73532545 -0.32444284 -1.04061541
  -0.81405762 -0.02554881 -1.43949446 -0.43189409 -0.0572036  -1.1562397
  -0.43401854 -0.39840954]
 [ 1.52709552 -0.64601991 -0.24077171  0.73532545 -0.32444284  0.96096982
  -0.81405762 -0.02554881 -1.43949446 -0.43189409 -0.0572036   0.86487257
  -0.43401854 -0.39840954]]
```

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png) 


Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
    <td>Clean and transform data to run kNN</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Define cross-validation and discuss how to use it</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
</table>

Congratulations on completing this module!
=================================================
<br>
<div style="text-align:center;">
You are now ready to try Tasks 1-8 in the Exercise for this topic
</div>
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
