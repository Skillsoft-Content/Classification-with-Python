---
title: 'Intro to classification - kNN - 3'
subtitle: 'One should look for what is and not what he thinks should be. (Albert Einstein)'
output:
 revealjs::revealjs_presentation:
  css: !expr here::here("dependencies/slides_rmd.css")
  transition: slide
  template: !expr here::here("dependencies/reveal_template.html")
  reveal_options:
    width: 1366
    height: 768
  keep_md: yes
params:
  topic_dir: !expr box::file()
---


















Field trip: Teachable Snake
=================================================
- Classifying with ~~kNN~~ can seem really simple due to the fact that it just stores training data rather than actively performing calculations
- Despite its simplicity, it is often at the core of complex classification tasks
- On a <b>white sheet of paper</b> or an <b>index card, draw an arrow</b>
- Then, visit https://teachable-snake.netlify.app/ to play a quick game of <b>Teachable Snake</b>

Teachable Snake debrief
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Believe it or not, kNN is at the core of Google Creative Lab’s Teachable Machine, a tool for creating ML models – learn more [here](https://teachablemachine.withgoogle.com/)
- Google’s boilerplate documentation, available via GitHub [here](https://github.com/googlecreativelab/teachable-machine-boilerplate), explains how to combine kNN with a neural network for image recognition
- Read more about Teachable Snake at the creator’s website by clicking [here](https://www.vinceshao.com/works/teachable-snake/)

:::
::: {.column width="50%"}

<div style="text-align:center;">
<img src="/opt/atlassian/pipelines/agent/build/dependencies/img/chat-q-snake.png" height=600, width=400>
</div>

:::
::::::

Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
    <td>Implement kNN algorithm on the training data without cross-validation</td>
    <td></td>
  </tr>
  <tr>
    <td>Identify performance metrics for classification algorithms and evaluate a simple kNN model</td>
    <td></td>
  </tr>
  <tr>
</table>


kNN: modeling with KNeighborsClassifier
=================================================
:::::: {.columns}
::: {.column width="50%"}
- We will use the `sklearn.neighbors` function, `KNeighborsClassifier` 
- We will be using mostly `sklearn` modules and functions for classification and machine learning

:::
::: {.column width="50%"}

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/KNeighborsClassifier.png)

:::
::::::
kNN: build model
=================================================
- We now will instantiate our kNN model and run it on `X_train`
- At first, we will simply run the model on our training data and predict on test
- We set `n_neighbors = 5` as a random guess; usually we can use 3 or 5
- We will use cross-validation to optimize our model next time
- Using this process, we will also choose the best `n_neighbors` for an optimal result


```python
# Create kNN classifier.
default = 5
kNN = KNeighborsClassifier(n_neighbors = default)
# Fit the classifier to the data.
kNN.fit(X_train, y_train)
```

```
KNeighborsClassifier()
```

<i>**Note that we typically choose an odd number of nearest neighbors to ensure that there are no 'ties'**</i>

kNN: predict on a test set
=================================================
- Now we will take our trained model and predict on a test set 

```python
predictions = kNN.predict(X_test)
```
- What we get is a vector of predicted values

```python
print(predictions[0:5])
```

```
[False False False False False]
```

kNN: predict on test
=================================================

- Let's quickly glance at our first five **actual observations** vs our first five ~~predicted observations~~
- This is helpful because we have the actual values for this
sample


```python
actual_v_predicted = np.column_stack((y_test, predictions))
print(actual_v_predicted[0:5])
```

```
[[False False]
 [False False]
 [False False]
 [False False]
 [False False]]
```



Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Implement kNN algorithm on the training data without cross-validation</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Identify performance metrics for classification algorithms and evaluate a simple kNN model</td>
    <td></td>
  </tr>
</table>

Classification: assessing performance
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Our outcome variable is **binary**, and we need to understand how to measure error in classification problems

:::
::: {.column width="50%"}

- The following terms are very important to measure 
performance of a classification algorithm

  - Confusion matrix
  - Accuracy
  - Receiver operating characteristic (ROC) curve
  - Area under the curve (AUC)
  
:::
::::::

Classification: sklearn.metrics
=================================================
:::::: {.columns}
::: {.column width="50%"}
- `sklearn.metrics` has many packages that are used to calculate metrics for various models
- We will be using metrics found within the *Classification metrics* section
- Here is an idea of what we can calculate using this library

:::
::: {.column width="50%"}

![centered-border](/opt/atlassian/pipelines/agent/build/dependencies/img/sklearn_metrics.png)

:::
::::::

Confusion matrix: what is it?
=================================================
- A ~~confusion matrix~~ is what we use to measure error
- We use it to calculate Accuracy, Misclassification rate, True positive rate, False positive rate, and Specificity
- In the matrix overview of our data, let `Y1` be "non-vulnerable" and `Y2` be "vulnerable"

  
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/cm_overview.png)

Confusion matrix: accuracy
=================================================
- We will now review the metrics we are looking for from the confusion matrix, one at a time

<b>Accuracy</b>: overall, how often is the classifier correct?

**TP + TN** / <b>total</b>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/cm_accuracy.png)

Confusion matrix: misclassification rate
=================================================
<b>Misclassification rate (error rate)</b>: overall, 
how often is the classifier wrong?

~~FP + FN~~ / <b>total</b>

<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/cm_misclassification.png)

Confusion matrix: true positive rate
=================================================
<b>True positive rate (Sensitivity)</b>: how
often does it predict yes?

**TP** / <b>actual yes</b>

<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/cm_truepositive.png)

Confusion matrix: false positive rate
=================================================
<b>False positive rate</b>: when it's actually no, how 
often does it predict yes?

~~FP~~ / <b>actual no</b>

<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/cm_falsepositive.png)

Confusion matrix: specificity
=================================================
<b>True Negative Rate (Specificity)</b>: when it's actually no, how often does it predict no?

~~TN~~ / <b>actual no</b>

<br>

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/cm_specificity.png)

Confusion matrix: summary
=================================================
- Here is a table with all the metrics in one place:

<table>
<tr>
  <th>Metric name</th>
  <th>Formula</th>
</tr>
<tr>
  <td>Accuracy</td>
  <td>True positive + True Negative / Overall total</td>
</tr>
<tr>
  <td>Misclassification rate</td>
  <td>False positive + False Negative / Overall total</td>
</tr>
<tr>
  <td>True positive rate</td>
  <td>True positive / Actual yes (True positive + False negative)</td>
</tr>
<tr>
  <td>False positive rate</td>
  <td>False positive / Actual no (False positive + True negative)</td>
</tr>
<tr>
  <td>Specificity</td>
  <td>True negative / Actual no (False positive + True negative)</td>
</tr>
</table>



Understanding medical tests: sensitivity, specificity, and positive predictive value
=================================================
- A test that’s highly sensitive will flag almost everyone who has the disease and not generate many false-negative results. (Example: a test with 90% sensitivity will correctly return a positive result for 90% of people who have the disease, but will return a negative result — a false-negative — for 10% of the people who have the disease and should have tested positive.)
- A high-specificity test will correctly rule out almost everyone who doesn’t have the disease and won’t generate many false-positive results. (Example: a test with 90% specificity will correctly return a negative result for 90% of people who don’t have the disease, but will return a positive result — a false-positive — for 10% of the people who don’t have the disease and should have tested negative.)

Understanding medical tests: Pregnancy test results
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/pregnancy_test.png)

Confusion matrix in python
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Now that we know the metrics behind the madness, let's execute the code to build a confusion matrix in Python
- We use a function called `confusion_matrix` from `sklearn.metrics` 


```python
# Confusion matrix for kNN.
cm_kNN = confusion_matrix(y_test, predictions)
print(cm_kNN)
```

```
[[1443    7]
 [  82    1]]
```

- We won't go through all of the metrics right now, but let's calculate accuracy because it's a metric used frequently to compare classification models

:::
::: {.column width="50%"}
- <b>Accuracy = True positive + True Negative / Overall total</b>
- Using `accuracy_score` from `sklearn.metrics`, we calculate:


```python
print(round(accuracy_score(y_test, predictions), 
4))
```

```
0.9419
```

:::
::::::
Confusion matrix: visualize
=================================================
:::::: {.columns}
::: {.column width="60%"}

- Let's visualize our confusion matrix


```python
plt.imshow(cm_kNN, interpolation = 'nearest', cmap = plt.cm.Wistia)
classNames = ['Negative', 'Positive']
plt.title('Confusion Matrix - Test Data')
plt.ylabel('True label')
plt.xlabel('Predicted label')
tick_marks = np.arange(len(classNames))
plt.xticks(tick_marks, classNames, rotation = 45)
plt.yticks(tick_marks, classNames)
s = [['TN', 'FP'], ['FN', 'TP']]
for i in range(2):
    for j in range(2):
        plt.text(j,i, str(s[i][j]) + " = " + str(cm_kNN[i][j]))
plt.show()
```

:::
::: {.column width="40%"}

![](/opt/atlassian/pipelines/agent/build/assets/1-IntroToClassification/kNN/IntroToClassification-kNN-3_files/figure-revealjs/unnamed-chunk-15-1.png)

:::
::::::
Evaluation of kNN with k neighbors
=================================================
- Let's store the accuracy of this model. This way we can access it later to compare.


```python
# Create a dictionary with accuracy values for our kNN model with k.
model_final_dict = {'metrics': ["accuracy"],
                    'values':[round(accuracy_score(y_test, predictions), 4)],
                    'model':['kNN_k']}
model_final = pd.DataFrame(data = model_final_dict)
print(model_final)
```

```
    metrics  values  model
0  accuracy  0.9419  kNN_k
```

- Our model is not doing great, but we will now observe how it does compared to other models.


Performance of our kNN model
=================================================
:::::: {.columns}
::: {.column width="50%"}
- The remaining metrics we want to look at to evaluate our model are:

  - Receiver operating characteristic (~~ROC~~) curve
  - Area under the curve (**AUC**)

:::
::: {.column width="50%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/performance_measurement.png)

:::
::::::
ROC: receiver operator characteristic 
=================================================
:::::: {.columns}
::: {.column width="45%"}

- ROC is a plot of the true positive rate (**TPR**) against the false positive rate (~~FPR~~)
- The plot illustrates the trade off between the TPR and FPR
- Classification models produce them to show the performance of the model and allow us to choose which threshold to use

:::
::: {.column width="55%"}
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/ROC_ex.png)


<div class="notes">
The ROC tests multiple threshold levels for the classifier. There could be an entire class reviewing ROC curves, it is beyond the scope of this course.
In the graph: This can also be noted with sensitivity on the y axis and specificity on the x axis. The area under the ROC curve is the area under the curve, which we will review next.
</div>

:::
::::::
AUC: area under the curve
=================================================
:::::: {.columns}
::: {.column width="45%"}
- The AUC is a **performance metric** used to compare classification models to measure ~~predictive accuracy~~
- The AUC should be <b>above .5</b> to say the model is better than a random guess
- The perfect AUC `= 1` (you will never see this number working with real world data!)

:::
::: {.column width="55%"}

![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/AUC_explained.png)

:::
::::::
Plot ROC and calculate AUC
=================================================
:::::: {.columns}
::: {.column width="50%"}
- Let's plot the ~~ROC~~ for our model and calculate the **AUC**


```python
# Store FPR, TPR, and threshold as variables.
fpr, tpr, threshold = metrics.roc_curve(y_test, predictions)
# Store the AUC.
roc_auc = metrics.auc(fpr, tpr)
```

```python
plt.title('Receiver Operating Characteristic')
plt.plot(fpr, tpr, 'b', label = 'AUC = %0.2f' % roc_auc)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()
```

:::
::: {.column width="50%"}

![](/opt/atlassian/pipelines/agent/build/assets/1-IntroToClassification/kNN/IntroToClassification-kNN-3_files/figure-revealjs/unnamed-chunk-18-1.png)

:::
::::::

Knowledge check
=================================================
![centered](/opt/atlassian/pipelines/agent/build/dependencies/img/knowledge_check.png) 


Module completion checklist
=================================================
<table>
  <tr>
    <th>Objective</th>
    <th>Complete</th>
  </tr>
  <tr>
    <td>Implement kNN algorithm on the training data without cross-validation</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
  <tr>
    <td>Identify performance metrics for classification algorithms and evaluate a simple kNN model</td>
    <td><p class="centered-text"><b class="green-emphasis" style="font-size: 42px;">&#10004;</b></p></td>
  </tr>
</table>

Congratulations on completing this module!
=================================================
<br>
<div style="text-align:center;">
You are now ready to try Tasks 9-13 in the Exercise for this topic
</div>
![icon-left-bottom](/opt/atlassian/pipelines/agent/build/dependencies/img/circles-crayon-purple.png)
